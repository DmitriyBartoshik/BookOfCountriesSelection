package com.brothersoft.domain.entity.country;

import java.util.List;

public class LanguageList {
    private List<Language> languages;

    public List<Language> getLanguages() {
        return languages;
    }
}
