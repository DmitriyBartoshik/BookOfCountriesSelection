package com.brothersoft.domain.executors;

import java.util.concurrent.Executor;

public interface ExecutionThread extends Executor{
}
