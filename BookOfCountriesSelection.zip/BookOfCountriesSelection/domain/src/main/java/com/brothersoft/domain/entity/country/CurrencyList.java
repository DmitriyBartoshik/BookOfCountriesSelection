package com.brothersoft.domain.entity.country;

import java.util.List;

public class CurrencyList {
    private List<Currency> currencies;

    public List<Currency> getCurrencies() {
        return currencies;
    }
}
