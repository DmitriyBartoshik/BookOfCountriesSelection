package com.brothersoft.domain.entity.country;

import java.util.List;

public class RegionalBlockList {
    private List<RegionalBlock> regionalBlocs;

    public List<RegionalBlock> getRegionalBlocs() {
        return regionalBlocs;
    }
}
