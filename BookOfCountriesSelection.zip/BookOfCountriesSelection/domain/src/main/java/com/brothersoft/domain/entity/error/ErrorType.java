package com.brothersoft.domain.entity.error;

public enum ErrorType {

    INTERNET_IS_NOT_AVAILABLE,
    SERVER_IS_NOT_AVAILABLE,
    SERVER_ERROR,
    UNEXPECTED_ERROR
}
