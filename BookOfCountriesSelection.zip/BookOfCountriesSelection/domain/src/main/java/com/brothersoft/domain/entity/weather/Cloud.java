package com.brothersoft.domain.entity.weather;

import com.brothersoft.domain.entity.DomainModel;

public class Cloud implements DomainModel {
    private int all;

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
