package com.brothersoft.domain.entity;

public interface DomainModel {
}
