package com.brothersoft.bookofcountry.presentation.utils;

public class Extras {
    public static final String EXTRA_COUNTRY_ALPHA3CODE = "EXTRA_COUNTRY_ALPHA3CODE";
    public static final String EXTRA_COUNTRY_FIELD = "EXTRA_COUNTRY_FIELD";
    public static final String EXTRA_COUNTRY_FIELD_CODE = "EXTRA_COUNTRY_FIELD_CODE";
    public static final String EXTRA_COUNTRY_FIELD_NAME = "EXTRA_COUNTRY_FIELD_NAME";
    public static final String EXTRA_COUNTRY_CAPITAL_NAME = "EXTRA_COUNTRY_CAPITAL_NAME";
    public static final String EXTRA_COUNTRY_CAPITAL_LAT = "EXTRA_COUNTRY_CAPITAL_LAT";
    public static final String EXTRA_COUNTRY_CAPITAL_LNG = "EXTRA_COUNTRY_CAPITAL_LNG";
}
