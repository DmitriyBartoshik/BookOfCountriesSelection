package com.brothersoft.bookofcountry.presentation.screens.country.capital;

import com.brothersoft.bookofcountry.presentation.base.BaseRouter;

public class CapitalRouter extends BaseRouter<CapitalActivity> {

    public CapitalRouter(CapitalActivity activity) {
        super(activity);
    }
}
