package com.brothersoft.bookofcountry.presentation.screens.selection.adapter;

public interface OnItemClickListener {
    void onItemClick(int position);
}
