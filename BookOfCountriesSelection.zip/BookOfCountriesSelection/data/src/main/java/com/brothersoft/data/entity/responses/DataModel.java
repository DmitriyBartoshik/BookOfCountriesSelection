package com.brothersoft.data.entity.responses;

public interface DataModel {
}
