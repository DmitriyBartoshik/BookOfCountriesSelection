package com.brothersoft.data.entity.responses.weather;

import com.brothersoft.data.entity.responses.DataModel;

public class CloudResponse implements DataModel {
    private int all;

    public int getAll() {
        return all;
    }
}
